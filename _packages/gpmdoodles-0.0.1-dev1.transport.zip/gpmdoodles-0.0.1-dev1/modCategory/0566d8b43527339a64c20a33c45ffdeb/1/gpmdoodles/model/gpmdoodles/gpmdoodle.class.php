<?php
/**
 * @package gpmdoodles
 */
class GPMDoodle extends xPDOObject {}
?>