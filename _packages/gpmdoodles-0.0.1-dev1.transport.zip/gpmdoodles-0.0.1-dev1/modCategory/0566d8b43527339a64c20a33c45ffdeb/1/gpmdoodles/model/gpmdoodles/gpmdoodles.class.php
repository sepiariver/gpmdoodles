<?php

require_once dirname(__DIR__) . '/vendor/autoload.php';

class GPMDoodles extends SepiaRiver\GPMDoodles {}