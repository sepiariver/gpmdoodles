# gpmdoodles

Companion to the tutorial at: https://sepiariver.com/modx/build-a-modx-extra-with-git-package-management/